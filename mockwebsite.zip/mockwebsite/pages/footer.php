<footer>

                <p style="text-align:center">
                    <img src="titlelogo.png" width="200" height="100">
                </p>

                <p style="text-align:center">
                    <?php
                        echo "<small style='font-family:garamond'> Copyright © 2005 - 2022 " . FILE_AUTHOR . "</small>";
                    ?>
                </p>
                
</footer> 